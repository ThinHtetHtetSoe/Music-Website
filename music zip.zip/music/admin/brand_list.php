<?php
include('../db.php');

$sql = "select * from brand";

$result_set = mysqli_query($conn, $sql);
$count = 0;

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

  <div class="container mt-3">
    <h2>Brand Table</h2>


    <div class="table-responsive">
      <table class="table table-bordered table-striped">

        <tbody>
          <?php
          while ($row = mysqli_fetch_assoc($result_set)) {
            $brand_id = $row['brand_id'];
            $brand_name = $row['brand_name'];

          ?>
            <tr>
              <td> <?php echo ++$count; ?></td>
              <td> <?php echo $brand_name; ?></td>
              <td><a href="edit_brand.php?brand_id= <?php echo $brand_id; ?>" class="btn btn-info btn-sm">Edit</a>
                <a class="btn btn-danger btn-sm" href="del_brand.php?brand_id= <?php echo $brand_id; ?>">Delete</a>
              </td>
            </tr>

          <?php
          }
          ?>

        </tbody>
      </table>
    </div>
  </div>
</body>

</html>