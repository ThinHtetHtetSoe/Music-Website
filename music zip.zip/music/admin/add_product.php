<?php

include('../db.php');

$sql_cat = "select * from category";
$sql_brand = "select * from brand";

$rs_cat = mysqli_query($conn, $sql_cat);
$rs_brand = mysqli_query($conn, $sql_brand);

if (isset($_POST['submit'])) {
    $productName = $_POST['productName'];
    $cat_id = $_POST['category'];
    $brand_id = $_POST['brand'];

    $sell_price = $_POST['sell_price'];
    $buy_price = $_POST['buy_price'];

    $qty = $_POST['stockQuantity'];
    $desc = $_POST['description'];

    $min_rand = rand(0, 1000);
    $max_rand = rand(100000000000, 10000000000000000);
    $name_file = rand($min_rand, $max_rand);

    $target_dir = "../img/";
    $item_photo = basename($_FILES["imageUpload"]["name"]);// 1.jpg
    $target_file = $target_dir . $item_photo; //../img/1.jpg
    move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deku Musical Online Shop - Add Product</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .container {
            max-width: 600px;
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        h2 {
            font-family: 'Playfair Display', serif;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .btn-primary {
            background-color: #333;
            border: none;
        }

        .btn-primary:hover {
            background-color: #555;
        }
    </style>
</head>

<body>

    <div class="container my-5">
        <h2 class="text-center mb-4">Add New Product</h2>
        <form action="product.php" method="post" enctype="multipart/form-data">
            <!-- Product Name -->
            <div class="mb-3">
                <label for="productName" class="form-label">Product Name</label>
                <input type="text" class="form-control" name="productName" placeholder="Enter product name" required>
            </div>

            <!-- Category Selection -->
            <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" name="category" required>
                    <option value="" disabled selected>Select category</option>
                    <?php
                    while ($row = mysqli_fetch_assoc($rs_cat)) {
                        ?>
                        <option value="<?php echo $row['cat_id'] ?>"> <?php echo $row['cat_name']; ?> </option>

                        <?php
                    }
                    ?>
                </select>
            </div>

            <!-- Brand Selection -->
            <div class="mb-3">
                <label for="brand" class="form-label">Brand</label>
                <select class="form-select" name="brand" required>
                    <option value="" disabled selected>Select brand</option>

                    <?php
                    while ($row = mysqli_fetch_assoc($rs_brand)) {
                        ?>
                        <option value=" <?php echo $row['brand_id'] ?>  "> <?php echo $row['brand_name']; ?> </option>
                        <?php
                    }

                    ?>

                </select>
            </div>

            <!-- Price -->
            <div class="mb-3">
                <label for="price" class="form-label">Buy Price</label>
                <input type="number" class="form-control" name="buy_price" placeholder="Enter price" min="0" required>
            </div>

            <!-- Price -->
            <div class="mb-3">
                <label for="price" class="form-label">Sell Price</label>
                <input type="number" class="form-control" name="sell_price" placeholder="Enter price" min="0" required>
            </div>
            <!-- Stock Quantity -->
            <div class="mb-3">
                <label for="stockQuantity" class="form-label">Stock Quantity</label>
                <input type="number" class="form-control" name="stockQuantity" placeholder="Enter quantity in stock"
                    min="0" required>
            </div>

            <!-- Description -->
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" name="description" rows="4" placeholder="Enter product description"
                    required></textarea>
            </div>

            <!-- Upload Image -->
            <div class="mb-3">
                <label for="imageUpload" class="form-label">Upload Product Image</label>
                <input type="file" class="form-control" name="imageUpload"
                    accept=".jpg,.jpeg,.png,.gif,.JPG,.JPEG,.PNG,.GIF" required>
            </div>

            <!-- Submit Button -->
            <button type="submit" name="submit" class="btn btn-primary w-100 mb-2">Add Product</button>
            <button type="reset" class="btn btn-danger w-100">Clear Product</button>
        </form>
    </div>
</body>
</html>