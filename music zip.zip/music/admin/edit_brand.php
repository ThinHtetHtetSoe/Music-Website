<?php
include('../db.php');

$brand_name = "";

if (isset($_GET['brand_id'])) {
  $brand_id = $_GET['brand_id'];
  $sql = "select brand_name from brand where brand_id='$brand_id'";
  $result = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($result);
  $brand_name = $row['brand_name'];
}




if (isset($_POST['btn'])) {
  $brand_id = $_POST['brand_id'];




  $brand_name = $_POST['brand_name'];



  $sql_up = "Update brand set brand_name='$brand_name' where brand_id='$brand_id'";
  $ans = mysqli_query($conn, $sql_up);
  if ($ans) {
    header('location:brand_list.php');
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

  <div class="container mt-3">
    <h2>Edit Brand</h2>
    <form action="edit_brand.php" method="post">
      <input type="hidden" name="brand_id" value="<?php echo $brand_id; ?> ">
      <div class="mb-3 mt-3">
        <label for="brand_name">Brand</label>
        <input type="text" class="form-control" id="brand_name" name="brand_name" value="<?php echo $brand_name; ?>">
      </div>
      <input type="submit" class="btn btn-primary" name="btn" value="Submit">
    </form>
  </div>

</body>

</html>