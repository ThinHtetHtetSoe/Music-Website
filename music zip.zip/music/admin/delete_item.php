

<?php
include('../db.php');

$pid=$_GET['pid'];
$sql= "delete from product where product_idt= '$pid' ";
$ans=mysqli_query($conn,$sql);
if($ans)
{
	header('Location:product_list.php');
}

echo $pid;



?>