<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffee Shop Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="img/logo.png">
   <style>
    /* General Styles */
body, html {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    box-sizing: border-box;
    background-color: #f4f4f4;
}

.container {
    display: grid;
    grid-template-areas: 
        "header header"
        "sidebar main"
        "footer footer";
    grid-template-rows: 60px 1fr 40px;
    grid-template-columns: 250px 1fr;
    min-height: 100vh;
}

/* Header */
.header {
    grid-area: header;
    background-color: #333;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 20px;
    font-size: 24px;
    font-weight: bold;

}

/* Sidebar */
.sidebar {
    grid-area: sidebar;
    background-color: #444;
    color: white;
    padding: 20px;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar li {
    margin: 15px 0;
    cursor: pointer;
    transition: background-color 0.3s;
    padding: 10px 5px;
    border-radius: 10px;
    background-color:#555;
}


/* Main Content */
.main-content {
    grid-area: main;
    background-color: white;
    padding: 0;
    border-left: 1px solid #ddd;
}

.main-content iframe {
    width: 100%;
    height: 100%;
    border: none;
}

/* Footer */
.footer {
    grid-area: footer;
    background-color: #142c28;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 20px;
}
.icon{
    color:#2daa95;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .container {
        grid-template-areas: 
            "header"
            "main"
            "sidebar"
            "footer";
        grid-template-rows: 50px 1fr auto 30px;
        grid-template-columns: 1fr;
    }

    .sidebar {
        padding: 5px;
    }

.sidebar li {
    display: inline-block;
     padding:10px;
     margin: 5px 0;
}


    .main-content {
        padding: 0;
    }
}

@media screen and (max-width: 480px) {
    .header, .footer {
        font-size: 15px;
        padding: 0 10px;
    }

    .sidebar ul {
        padding: 0;
    }
    .sidebar {
        padding: 5px;
    }

    .sidebar li {
        
     font-size: 14px;
     display: inline-block;
     padding:10px;
     margin: 5px 0;
    }
}
   </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <img src="../img/logo.jpg" style="width: 40px;height:40px;border-radius: 50% "> &nbsp; Coffee Shop Admin Panel</header>
        <nav class="sidebar">
            <ul>
                <li >&nbsp;Category                 
                    <ul style="margin-left: 10px" class="myul">
                      <li onclick="loadPage('category.php')"><i class="fa fa-stack-overflow icon" style="font-size:20px"></i>&nbsp;Add Category</li>
                      <li onclick="loadPage('category_list.php')"><i class="fa fa-database icon" style="font-size:20px"></i>&nbsp;Category Lists</li>
                    </ul>

                </li>

                <li >&nbsp;Brands

                  <ul style="margin-left: 10px">
                      <li onclick="loadPage('brand.php')"><i class="fa fa-id-card-o icon" style="font-size:20px"></i>&nbsp;Add Band</li>
                      <li onclick="loadPage('brand_list.php')"><i class="fa fa-database icon" style="font-size:20px"></i>&nbsp;Brand Lists</li>
                    </ul>
                </li>


                <li >&nbsp;Products
                 <ul style="margin-left: 10px">
                      <li  onclick="loadPage('product.php')"><i class="fa fa-product-hunt icon" style="font-size:20px"></i>&nbsp;Add Product</li>
                      <li onclick="loadPage('product_list.php')"><i class="fa fa-database icon" style="font-size:20px"></i>&nbsp;Product List</li>
                  </ul>

                </li>
                
            </ul>
        </nav>

        <main class="main-content">
            <iframe id="content-frame" src="grid.html" frameborder="0"></iframe>
        </main>

        <footer class="footer">©2024. All copyright reserved</footer>

    </div>

<script>
        
function loadPage(pageUrl) {
    const iframe = document.getElementById('content-frame');
    iframe.src = pageUrl;
}

// Set the default view to Dashboard
document.addEventListener('DOMContentLoaded', function() {
    loadPage('home.php');
});

    </script>
</body>
</html>