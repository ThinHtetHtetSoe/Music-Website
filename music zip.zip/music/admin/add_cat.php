<?php

include('../db.php');

$message = "No Insertion";

if (isset($_POST['btn'])) {

  $cat_name = $_POST['cat_name'];

  $retrive_sql = "select * from category where cat_name='$cat_name'";
  $rs = mysqli_query($conn, $retrive_sql);
  $count = mysqli_num_rows($rs);

  if ($count > 0) {
    $message = $cat_name . " is already existed";
  } else {
    $sql = "insert into category(cat_name) values ('$cat_name')";
    $ans = mysqli_query($conn, $sql);
    if ($ans) {
      $message = $cat_name . " is added !";
    } else {
      $message = "Error";
    }
  }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

  <div class="container mt-3">
    <div class="alert alert-info alert-dismissible fade show">
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      <strong><?php echo $message; ?></strong>
    </div>
    <h2>New Category</h2>

    <form action="add_cat.php" method="post">

      <div class="mb-3 mt-3">
        <label for="email">Category Name</label>
        <input required type="text" class="form-control" id="email" placeholder="Enter Category" name="cat_name">
      </div>

      <button type="submit" class="btn btn-primary" name="btn">Add Category</button>
      <button type="reset" class="btn btn-danger">Clear</button>

    </form>
  </div>

</body>

</html>