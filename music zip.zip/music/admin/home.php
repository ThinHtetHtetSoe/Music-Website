<?php
//session_start();
include('../db.php'); // $conn


//if (!isset($_SESSION['admin_logged_in'])) {
  //  header('Location: login.php'); // Redirect to login if not logged in
  //  exit;
//}

// Fetch the count of brands
$queryCategory = "SELECT COUNT(*) AS total_category FROM category";
$resultCategory = mysqli_query($conn, $queryCategory);
$rowCategory = mysqli_fetch_assoc($resultCategory);
$totalCategory = $rowCategory['total_category'];

// Fetch the count of categories
//$queryCategories = "SELECT COUNT(*) AS total_categories FROM categories";
//$resultCategories = mysqli_query($conn, $queryCategories);
//$rowCategories = mysqli_fetch_assoc($resultCategories);
//$totalCategories = $rowCategories['total_categories'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .card {
            margin: 20px;
        }
        .dashboard-container {
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 bg-dark text-white  p-3">
            <h2 class="text-left">Admin Dashboard</h2>
        </div>
    </div>

    <div class="row dashboard-container">
        

        <!-- Categories Summary -->
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-header bg-success text-white">
                    <h4><i class="fas fa-th-large"></i> Categories Summary</h4>
                </div>
                <div class="card-body">
                    <h5>Total Categories</h5>
                    <h2><?php echo $totalCategory; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Categories Summary -->

</div>

<!-- JavaScript for Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

