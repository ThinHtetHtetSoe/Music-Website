<?php

include('../db.php');

$message = "No Insertion";

if (isset($_POST['btn'])) {

  $brand_name = $_POST['brand_name'];

  $retrive_sql = "select * from brand where brand_name='$brand_name'";

  $rs = mysqli_query($conn, $retrive_sql);

  $count = mysqli_num_rows($rs);

  if ($count > 0) {
    $message = $brand_name . " is already existed";
  } else {
    $sql = "insert into brand(brand_name) values ('$brand_name')";

    $ans = mysqli_query($conn, $sql);

    if ($ans) {
      $message = $brand_name . " is added !";
    } else {
      $message = "Error";
    }
  }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

  <div class="container mt-3">
    <div class="alert alert-info alert-dismissible fade show">
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      <strong><?php echo $message; ?></strong>
    </div>
    <h2>New Brand</h2>

    <form action="add_brand.php" method="post">

      <div class="mb-3 mt-3">
        <label for="email">Brand Name</label>
        <input required type="text" class="form-control" id="email" placeholder="Enter Brand" name="brand_name">
      </div>

      <button type="submit" class="btn btn-primary" name="btn">Add Brand</button>
      <button type="reset" class="btn btn-danger">Clear</button>

    </form>
  </div>

</body>

</html>