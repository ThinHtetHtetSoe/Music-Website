?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>edit item</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Edit Product Form</h2>
  <form action="edit_product.php">

<input type="hidden" value="<?php echo $product_id; ?>" name="product_id">
    <div class="mb-3 mt-3">
      <label for="product_name">Product Name</label>
      <input type="product_name" class="form-control" value="<?php echo $pname; ?>" name="product_name">
    </div>
    
    <div class="mb-3">
    <label for="sel1" class="form-label">Category</label>
    <select class="form-select" id="sel1" name="sellist1">
      <?php
      while($row=mysqli_fetch_assoc($rs_cat))
      {
      	$selected = ($row['cat_id'] == $cat_id) ? 'selected' : '';
      ?>
      <option value="<?php echo $row['cat_id']; ?>" <?php echo $selected; ?> >
      	<?php echo $row['cat_name']; ?></option>
      <?php
      }
      ?>
    </select>
  </div>
    <div class="mb-3">
    <label for="sel1" class="form-label">Brand</label>
    <select class="form-select" id="sel1" name="sellist1">
      <?php
      while($row=mysqli_fetch_assoc($rs_brand))
      {

$selected = ($row['brand_id'] == $brand) ? 'selected' : '';

      ?>
      <option  value="<?php echo $row['brand_id']; ?>"    <?php echo $selected; ?>  > <?php echo $row['brand_name']; ?></option>
      <?php
      }
      ?>
    </select>
  </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>

   <?php
include('../db.php');

$sql_cat = "SELECT * FROM category";     
$result_cat=mysqli_query($conn,$sql_cat);

$sql_brand = "SELECT * FROM brand";     
$result_brand=mysqli_query($conn,$sql_brand);


if (isset($_GET['pid'])) 
{
     $p_id=$_GET['pid'];// pk

     $sql = "SELECT * FROM product WHERE product_id = '$p_id'"; 

     $result=mysqli_query($conn,$sql);
     
     $row = mysqli_fetch_assoc($result);

     $photo = $row['photo']; // get photo name
     $product_name = $row['product_name']; // get item  name
     $category_id = $row['category_id']; // get cat_Id
     $brand_id = $row['brand_id']; // get brand_id
     $buy_price = $row['buy_price']; // get buy_price
     $sell_price = $row['sell_price']; // get sell_price
     $qty = $row['qty']; // get qty
     $description = $row['description']; // get description
}

if (isset($_POST['update'])) 
{
    $pid=$_POST['pid'];

    $query= "SELECT * FROM product WHERE product_id = '$pid' ";
    $rs = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($rs);


    $product_name=$_POST['pname'];
    $category_id=$_POST['category'];
    $brand_id=$_POST['brand'];

     $buy_price = $row['buy_price']; // get buy_price
     $sell_price = $row['sell_price']; // get sell_price
     $qty = $row['qty']; // get qty
     $description = $row['description']; // get description

     

     if (!empty($_FILES['item_photo']['name'])) 
     { 

    $min_rand=  rand(0,1000);
    $max_rand=  rand(100000000000,10000000000000000);
    $name_file = rand($min_rand,$max_rand); // 2145012334758824

    $file_parts = explode(".", $_FILES["item_photo"]["name"]);  //creates an array where each part of the filename is a separate item => ["gold", "png"] for gold.png
    $ext = end($file_parts);   // png 
    $new_photo_name = $name_file. "." . $ext; // 2145012334758824.png

    $target_dir = "../img/";   
    $target_file = $target_dir . $new_photo_name; //    ../img/2145012334758824.png
    


    if (move_uploaded_file($_FILES['item_photo']['tmp_name'], $target_file)) 
          { 
            
             echo $row['photo'];
               if (!empty($row['photo']) && file_exists("../img/". $row['photo'])) 
               {
                   unlink("../img/".$row['photo']);
               }
          }

     }




}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Item</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Edit Product Form</h2>
  <form action="edit_item.php" method="post" enctype="multipart/form-data">

    <input type="hidden" value="<?php echo $p_id; ?>" name="pid">

    <div class="form-group my-2">
        <label for="item_name">Product Name</label>
        <input type="text" class="form-control"  name="pname" value="<?php echo $product_name; ?>" required>
    </div>    
    
    <div class="my-2">
    <label for="name">Category:</label>
    <select class="form-select" name="category">
      
      <?php
       while($row=mysqli_fetch_assoc($result_cat))
       {
        $selected = ($row['cat_id'] == $category_id) ? 'selected' : '';
       ?>
          <option value="<?php echo $row['cat_id']; ?>" <?php echo $selected; ?> >
                <?php echo $row['cat_name']; ?>
          </option>
       <?php 
       }
       ?>
      
    </select>
</div>

<div class="my-2">
    <label for="name">Brand:</label>
    <select class="form-select" id="sel1" name="brand">
      
      <?php
       while($row=mysqli_fetch_assoc($result_brand))
       {
        $selected = ($row['brand_id'] == $brand_id) ? 'selected' : '';
       ?>
          <option value="<?php echo $row['brand_id']; ?>" <?php echo $selected; ?> >
                <?php echo $row['brand_name']; ?>
          </option>
       <?php 
       }
       ?>
      
    </select>
</div>

<div class="form-group my-2">
        <label for="item_name">Buy Price</label>
        <input type="text" class="form-control"  name="bPrice" value="<?php echo $buy_price; ?>" required>
</div>

<div class="form-group my-2">
        <label for="item_name">Sell Price</label>
        <input type="text" class="form-control"  name="sPrice" value="<?php echo $sell_price; ?>" required>
</div>  

  

<div class="form-group my-2">
        <label for="item_name">Qty</label>
        <input type="text" class="form-control"  name="qty" value="<?php echo $qty; ?>" required>
</div>  

<div class="form-group my-2">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" name="description" rows="4"  required><?php echo $description; ?></textarea>
</div>

<div class="form-group my-2">
    <label for="item_photo">Product Photo</label><br>
    <img id="preview"  src="../img/<?php echo $photo; ?>" width="100" height="100" alt="Current Photo" class="rounded"><br><br>
    <input type="file" class="form-control-file" id="item_photo" name="item_photo" onchange="previewPhoto(event)" >
</div>

<button type="submit" class="btn btn-primary my-4 btn-lg float-end" name="update">Update</button>
  </form>
</div>

<script>
    function previewPhoto(event) 
    {
        const input = event.target; // Get the file input
        const preview = document.getElementById('preview'); // Get the img element

        if (input.files[0]) 
        {
            const reader = new FileReader();

            // Set the image src after the file is read
            reader.onload = function (e) 
            {
                preview.src = e.target.result; // Set the src to the file's content
            };

            reader.readAsDataURL(input.files[0]); // Read the file as a data URL
        }
    }
</script>

</body>
</html>


