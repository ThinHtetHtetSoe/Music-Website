<?php
include('../db.php');

$cat_id = $_GET['cat_id'];

$sql = "delete category from category where cat_id='$cat_id'";
$ans = mysqli_query($conn, $sql);

if ($ans) {
	header("Location:category_list.php");
}
