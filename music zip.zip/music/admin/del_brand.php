<?php
include('../db.php');

$brand_id = $_GET['brand_id'];

$sql = "delete brand from brand where brand_id='$brand_id'";
$ans = mysqli_query($conn, $sql);

if ($ans) {
	header("Location:brand_list.php");
}
