<?php
include('../db.php');
$cat_id=$_GET['cat_id'];// pk
$sql="select cat_name from category where cat_id='$cat_id'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$cat_name=$row['cat_name'];


if(isset($_POST['btn']))
{
  $cat_id=$_POST['cat_id'];
  $cat_name= $_POST['cat_name'];
  $sql_up="update category set cat_name='$cat_name' where cat_id='$cat_id'";
  $ans=mysqli_query($conn, $sql_up);
  if($ans)
   {
     header('Location:category_list.php');
   }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Music</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Edit Catgory</h2>
  <form action="edit.php" method="post">

 <input type="hidden" name="cat_id" value="<?php echo $cat_id; ?>">

    <div class="mb-3 mt-3">
      <label for="cat">Category</label>
      <input type="text" class="form-control" name="cat_name" value="<?php echo $cat_name; ?>    ">
    </div>    
    
    <button type="submit" class="btn btn-primary"   name="btn">Update</button>
  </form>
</div>

</body>
</html>
