<?php

$server = "localhost:5222";
$user = "root";
$pass= "root";
$db_name = "music";

$conn = mysqli_connect($server,$user,$pass,$db_name); 

//echo "ok";

?>